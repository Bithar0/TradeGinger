import { createClient } from '@supabase/supabase-js'
function admins(){ return (process.env.ADMIN_EMAILS||'').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean) }
async function sendEmail({ to, subject, html }){
  const key=process.env.RESEND_API_KEY, from=process.env.EMAIL_FROM||'TradeGinger <noreply@tradeginger.com>'
  if(!key||!to) return
  const res=await fetch('https://api.resend.com/emails',{ method:'POST', headers:{ 'Authorization':`Bearer ${key}`,'Content-Type':'application/json' }, body: JSON.stringify({ from, to: Array.isArray(to)?to:[to], subject, html }) })
  if(!res.ok) console.log('Resend error', await res.text())
}
export async function handler(event){
  if(event.httpMethod!=='POST') return { statusCode:405, body:'Method Not Allowed' }
  const url=process.env.SUPABASE_URL, key=process.env.SUPABASE_SERVICE_ROLE
  const s=createClient(url,key)
  const tok=(event.headers.authorization||'').replace(/^Bearer\s+/i,'')
  const { data:ud, error:ue } = await s.auth.getUser(tok)
  if(ue||!ud?.user?.email) return { statusCode:401, body:'Unauthorized' }
  const email=ud.user.email.toLowerCase()
  if(!admins().includes(email)) return { statusCode:401, body:'Unauthorized' }
  let b={}; try{ b=JSON.parse(event.body||'{}') }catch{}
  const { id, action, reason } = b
  if(!id||!action) return { statusCode:400, body:'Missing id/action' }
  const { data: listing } = await s.from('listings').select('id,title,seller_email').eq('id', id).single()
  const status = (action==='approve') ? 'approved' : 'rejected'
  const patch = { status, reviewed_by: email, reviewed_at: new Date().toISOString(), rejection_reason: status==='rejected'?(reason||''):null }
  const { error } = await s.from('listings').update(patch).eq('id', id)
  if(error) return { statusCode: 500, body: error.message }
  const site = process.env.SITE_URL || 'https://tradeginger.com'
  if(status==='approved'){ await sendEmail({ to: listing?.seller_email, subject:`Your listing is live: ${listing?.title}`, html:`<p>Great news! <strong>${listing?.title}</strong> is approved.</p><p><a href="${site}/l/${id}">View your listing</a></p>` }) }
  else { await sendEmail({ to: listing?.seller_email, subject:`Listing rejected: ${listing?.title}`, html:`<p>Sorry — <strong>${listing?.title}</strong> was rejected.</p><p>Reason: ${patch.rejection_reason||'Not specified'}</p>` }) }
  try{ await fetch(`${site}/.netlify/functions/bust-edge-cache`, { method:'POST' }) }catch{}
  return { statusCode: 200, body: JSON.stringify({ ok:true }) }
}
