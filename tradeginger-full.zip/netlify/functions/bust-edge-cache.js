import { createClient } from '@supabase/supabase-js'
export async function handler(event){
  if(event.httpMethod!=='POST') return { statusCode:405, body:'Method Not Allowed' }
  const url=process.env.SUPABASE_URL, key=process.env.SUPABASE_SERVICE_ROLE
  const s=createClient(url,key)
  const { error } = await s.from('edge_meta').upsert([{ key:'version', val: String(Date.now()) }], { onConflict: 'key' })
  if(error) return { statusCode:500, body:error.message }
  return { statusCode:200, body: JSON.stringify({ ok:true }) }
}
