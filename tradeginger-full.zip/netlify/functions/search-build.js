import { createClient } from '@supabase/supabase-js'
export async function handler(event){
  if (event.httpMethod !== 'GET') return { statusCode: 405, body: 'Method Not Allowed' }
  const p = event.queryStringParameters || {}
  const q = (p.q || '').trim()
  const category = (p.category || '').trim()
  const minPrice = p.minPrice ? parseInt(p.minPrice, 10) : null
  const maxPrice = p.maxPrice ? parseInt(p.maxPrice, 10) : null
  const sort = p.sort || 'new'
  const page = Math.max(1, parseInt(p.page || '1', 10))
  const pageSize = Math.min(50, Math.max(10, parseInt(p.pageSize || '24', 10)))
  const offset = (page - 1) * pageSize
  const supabaseUrl = process.env.SUPABASE_URL
  const key = process.env.SUPABASE_SERVICE_ROLE || process.env.SUPABASE_ANON_KEY
  const s = createClient(supabaseUrl, key)
  let query = s.from('listings').select('id,title,price,images,category,created_at,location,condition,brand,lat,lng', { count:'exact' }).eq('status','approved')
  if(q) query = query.or(`title.ilike.%${q}%,category.ilike.%${q}%`)
  if(category) query = query.eq('category', category)
  if(minPrice!=null) query = query.gte('price', minPrice)
  if(maxPrice!=null) query = query.lte('price', maxPrice)
  if(sort==='price_asc') query = query.order('price', { ascending:true })
  else if(sort==='price_desc') query = query.order('price', { ascending:false })
  else query = query.order('created_at', { ascending:false })
  query = query.range(offset, offset + pageSize - 1)
  const { data, error, count } = await query
  if (error) return { statusCode: 500, body: error.message }
  return { statusCode: 200, body: JSON.stringify({ items: data||[], page, pageSize, total: count||0 }) }
}
