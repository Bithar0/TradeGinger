import { createClient } from '@supabase/supabase-js'
export async function handler(event){
  if (event.httpMethod !== 'POST') return { statusCode: 405, body:'Method Not Allowed' }
  const url=process.env.SUPABASE_URL, key=process.env.SUPABASE_SERVICE_ROLE
  const s=createClient(url,key)
  const auth=(event.headers.authorization||'').replace(/^Bearer\s+/i,'')
  const { data:udat, error:uerr } = await s.auth.getUser(auth)
  if(uerr || !udat?.user?.id) return { statusCode: 401, body:'Unauthorized' }
  let patch={}; try{ patch=JSON.parse(event.body||'{}') }catch{}
  const id=patch.id; delete patch.id; if(!id) return { statusCode: 400, body:'Missing id' }
  patch.updated_at=new Date().toISOString()
  const { error } = await s.from('listings').update(patch).eq('id', id).eq('seller_id', udat.user.id)
  if(error) return { statusCode: 500, body:error.message }
  return { statusCode: 200, body: JSON.stringify({ ok:true }) }
}
