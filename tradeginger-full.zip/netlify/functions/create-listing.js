import { createClient } from '@supabase/supabase-js'
export async function handler(event){
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' }
  const url = process.env.SUPABASE_URL, key = process.env.SUPABASE_SERVICE_ROLE
  const s = createClient(url, key)
  const auth = (event.headers.authorization || '').replace(/^Bearer\s+/i,'')
  const { data: udat, error: uerr } = await s.auth.getUser(auth)
  if (uerr || !udat?.user) return { statusCode: 401, body: 'Unauthorized' }
  let body={}; try{ body=JSON.parse(event.body||'{}') }catch{}
  const now = new Date().toISOString()
  const row = { id: body.id || ('ad-'+Date.now()), title: body.title || '', price: body.price || 0, category: body.category || 'misc', images: body.images || [], location: body.location || '', condition: body.condition || '', brand: body.brand || '', city: null, state: null, country: 'IN', lat: null, lng: null, seller_id: udat.user.id, seller_email: udat.user.email, status: 'pending', created_at: now, updated_at: now }
  try { const res=await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&q='+encodeURIComponent(row.location||''), { headers:{'User-Agent':'tradeginger.com geocoder'} }); if(res.ok){ const arr=await res.json(); if(arr&&arr[0]){ row.lat=parseFloat(arr[0].lat); row.lng=parseFloat(arr[0].lon) } } } catch {}
  const { data, error } = await s.from('listings').insert([row]).select('*').single()
  if (error) return { statusCode: 500, body: error.message }
  return { statusCode: 200, body: JSON.stringify(data) }
}
