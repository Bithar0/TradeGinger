export async function handler(event){
  if (event.httpMethod !== 'GET') return { statusCode:405, body:'Method Not Allowed' }
  const q=(event.queryStringParameters&&event.queryStringParameters.q||'').trim()
  if(!q) return { statusCode:400, body:'Missing q' }
  try{ const res=await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&q='+encodeURIComponent(q),{ headers:{'User-Agent':'tradeginger.com geocoder'}}); if(!res.ok) throw new Error('Geocode error'); const arr=await res.json(); const p=arr&&arr[0]; return { statusCode:200, body: JSON.stringify(p?{ lat:parseFloat(p.lat), lng:parseFloat(p.lon), display_name:p.display_name }:null) } }catch(e){ return { statusCode:500, body:e.message||'Error' } }
}
