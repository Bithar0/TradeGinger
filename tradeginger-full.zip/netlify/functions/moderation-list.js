import { createClient } from '@supabase/supabase-js'
function admins(){ return (process.env.ADMIN_EMAILS||'').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean) }
export async function handler(event){
  const url=process.env.SUPABASE_URL, key=process.env.SUPABASE_SERVICE_ROLE
  const s=createClient(url,key)
  const tok=(event.headers.authorization||'').replace(/^Bearer\s+/i,'')
  const { data:ud, error:ue } = await s.auth.getUser(tok)
  if(ue||!ud?.user?.email) return { statusCode: 401, body:'Unauthorized' }
  const email=ud.user.email.toLowerCase()
  if(!admins().includes(email)) return { statusCode: 401, body:'Unauthorized' }
  const { data, error } = await s.from('listings').select('id,title,price,images,location,created_at,seller_email').eq('status','pending').order('created_at',{ascending:true}).limit(200)
  if(error) return { statusCode: 500, body:error.message }
  return { statusCode: 200, body: JSON.stringify(data||[]) }
}
