export { handler } from './search-build.js'
