export default async (request, context) => {
  const url = new URL(request.url)
  const name = decodeURIComponent(url.pathname.split('/').slice(2).join('/'))
  const html = `<!doctype html><html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/><title>${name} — TradeGinger</title></head><body><div style="max-width:1100px;margin:20px auto;padding:0 16px"><h1 style="font-weight:800;font-size:28px">${name}</h1></div><script>setTimeout(()=>{ if(!location.pathname.startsWith('/category/')) history.replaceState({},'', '/category/'+encodeURIComponent('${name}')); },300)</script></body></html>`
  return new Response(html, { headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control':'public, max-age=600' } })
}