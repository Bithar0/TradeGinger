export default async (request, context) => {
  const url = new URL(request.url)
  const id = decodeURIComponent(url.pathname.split('/').pop())
  const site = Deno.env.get('SITE_URL') || url.origin
  const html = `<!doctype html><html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/><title>Listing — TradeGinger</title><meta name="description" content="Listing on TradeGinger"/></head><body><div style="max-width:1100px;margin:20px auto;padding:0 16px"><h1 style="font-weight:800;font-size:28px">Listing</h1><p>ID: ${id}</p></div><script>setTimeout(()=>{ if(!location.pathname.startsWith('/l/')) history.replaceState({},'', '/l/'+encodeURIComponent('${id}')); },300)</script></body></html>`
  return new Response(html, { headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control':'public, max-age=600' } })
}