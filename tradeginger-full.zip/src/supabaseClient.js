import { createClient } from '@supabase/supabase-js'
export const SUPABASE_URL='https://crepnlidfdoskighdhdt.supabase.co'
export const SUPABASE_ANON_KEY='sb_publishable_-Pyl-st1O5MFTZlnS3AlDA_wXBz6v1s'
export const supabase=createClient(SUPABASE_URL,SUPABASE_ANON_KEY)
